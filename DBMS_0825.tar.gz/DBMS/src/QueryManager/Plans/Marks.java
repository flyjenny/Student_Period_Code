package QueryManager.Plans;

public interface Marks {
	public final static int SELECTEXP = 1;
	public final static int CREATEEXP = 2;
	public final static int INSERTEXP = 3;
	public final static int DROPEXP = 4;
	public final static int DELETEEXP = 5;
	public final static int UPDATEEXP = 6;
	public final static int ALTEREXP = 7;

	public final static int SELECTOP = 11;
	public final static int SELECTBINEXP = 12;
}
