package QueryManager.Parser;

public class Driver {

	public static void main(String[] argv) {
		String[] str = new String[1];
		str[0] = "/home/micro2fly/workspace/testcases/testcase1.sql";
		Main.main(str);
	}

}
