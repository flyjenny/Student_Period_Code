package Semant;


abstract public class Entry {
	public void display(){}
}




