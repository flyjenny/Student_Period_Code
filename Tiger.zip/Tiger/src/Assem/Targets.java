package Assem;

public class Targets {
  public Temp.LabelList labels;
  public Targets(Temp.LabelList l) {labels=l;}
}
