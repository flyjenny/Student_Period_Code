package Absyn;

abstract public class Exp extends Absyn {
}
