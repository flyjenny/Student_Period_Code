package Absyn;

abstract public class Dec extends Absyn {}
