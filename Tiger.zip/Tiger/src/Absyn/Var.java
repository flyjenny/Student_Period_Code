package Absyn;

abstract public class Var extends Absyn {
}
