package Absyn;

abstract public class Ty extends Absyn {}
