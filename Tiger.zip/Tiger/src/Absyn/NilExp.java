package Absyn;

public class NilExp extends Exp {
  public NilExp(int p) {pos=p;}
}
