package Absyn;
abstract public class Absyn {
  public int pos;
}
