package FindEscape;

abstract class Escape {
	int depth;
	abstract void setEscape();
}
