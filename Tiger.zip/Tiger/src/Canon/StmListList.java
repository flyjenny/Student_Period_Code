package Canon;

public class StmListList {
  public Tree.StmList head;
  public StmListList tail;
  public StmListList(Tree.StmList h, StmListList t) {head=h; tail=t;}
}

