package Frame;
/** interface of Access:represent a variable */
public interface Access {
    public Tree.Expv Fpexp( Tree.Expv faddr );
}