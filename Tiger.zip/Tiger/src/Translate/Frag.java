package Translate;

public class Frag {	
	public Frag tail;
}

