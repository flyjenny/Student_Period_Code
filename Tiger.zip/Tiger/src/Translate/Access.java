package Translate;

public class Access {
	public Level home;
	public Frame.Access acc;

	Access(Level h,Frame.Access a){
		home = h;
		acc = a;
	}
}
